import React, { Component } from "react";
import ReactDOM from "react-dom";
import SliderGlide from "./SliderGlide";
import OfferProduct from "./OfferProduct";
import Wrapper from "./wrapper";

import "./styles.css";

class Plans extends Component {

  constructor(props) {
    super(props);
    this.state = {
      data: [],
      counter: 0,
    };
  }

  componentDidMount() {

  }

  listItem = {
    myPlans: [
      { id: 0, text: "plan 0", price: 0 },
      { id: 1, text: "plan 1", price: 1 },
      { id: 2, text: "plan 2", price: 2 },
      { id: 3, text: "plan 3", price: 3 }
    ]
  };
  handleOffer = id => {
  };

  handleAdd = () => {
    const newitem = { id: this.listItem.myPlans.length, text: "plan " + this.listItem.myPlans.length, price: this.listItem.myPlans.length };
    this.listItem.myPlans.push(newitem);
    this.state.data = this.listItem;
    this.state.counter = this.listItem.length
    this.forceUpdate();
  };

  render() {
    const carouselOptions = { type: "slide", perView: 1, startAt: this.listItem.myPlans.length-1, itemchange: this.state.counter };
    return (
      <>
      <Wrapper />
      <div className="home-section test">
        <SliderGlide options={carouselOptions}>
          {this.listItem.myPlans.map(plan => (
            <OfferProduct
              key={plan.id}
              plan={plan}
              handleOffer={this.handleOffer}
            />
          ))}
        </SliderGlide>
        <button type="button" onClick={this.handleAdd}>Add Item</button>
      </div>
      <div>

      </div>
      </>
      
    );
  }
}
export default Plans;

const rootElement = document.getElementById("root");
ReactDOM.render(<Plans />, rootElement);
