import React from "react";

const OfferProduct = ({ plan, handleOffer }) => {
  return (
    <>
      <div onClick={() => handleOffer(plan.id)} className="card">
        <div>
          <h3> Card no: {plan.id} </h3>
          <span>price: {plan.price}</span>
        </div>
      </div>
    </>
  );
};

export default OfferProduct;
