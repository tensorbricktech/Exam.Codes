import React from "react";
function Wrapper() {
    return (

        <div>
        <OuterComponent>
          <InnerComponent />
        </OuterComponent>
      </div>
     
    );
  }
  function OuterComponent(props) {
    return props.children;
  }
  function InnerComponent() {
    return <div></div>;
  }
  export default Wrapper;